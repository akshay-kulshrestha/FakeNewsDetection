# models/lstm_model.py
# This module defines the LSTM classifier model.

try:
    import torch
    import torch.nn as nn
    TORCH_AVAILABLE = True
except ModuleNotFoundError:
    TORCH_AVAILABLE = False
    print("Warning: PyTorch is not installed. The LSTMClassifier model will be a stub.")

if TORCH_AVAILABLE:
    class LSTMClassifier(nn.Module):
        def __init__(self, vocab_size, embed_dim, hidden_dim, output_dim):
            super(LSTMClassifier, self).__init__()
            self.embedding = nn.Embedding(vocab_size, embed_dim)
            self.lstm = nn.LSTM(embed_dim, hidden_dim, batch_first=True)
            self.fc = nn.Linear(hidden_dim, output_dim)
            self.softmax = nn.LogSoftmax(dim=1)

        def forward(self, x):
            x = self.embedding(x)
            _, (hidden, _) = self.lstm(x)
            out = self.fc(hidden[-1])
            return self.softmax(out)
else:
    class LSTMClassifier:
        def __init__(self, *args, **kwargs):
            raise ImportError("PyTorch is required to use LSTMClassifier. Please install it using 'pip install torch'.")
